public abstract class Observer {
    public int i = 0;
    abstract public void setnum(int n);
    abstract public void display();

}
